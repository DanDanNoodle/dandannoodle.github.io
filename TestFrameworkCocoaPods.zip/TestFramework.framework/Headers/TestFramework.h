//
//  TestFramework.h
//  TestFramework
//
//  Created by Huang, Haodan on 10/23/17.
//  Copyright © 2017 Haodan Huang. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TestFramework.
FOUNDATION_EXPORT double TestFrameworkVersionNumber;

//! Project version string for TestFramework.
FOUNDATION_EXPORT const unsigned char TestFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestFramework/PublicHeader.h>


